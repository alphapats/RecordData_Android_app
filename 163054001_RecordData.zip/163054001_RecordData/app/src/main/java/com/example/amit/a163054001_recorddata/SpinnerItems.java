package com.example.amit.a163054001_recorddata;

/**
 * Created by Amit on 23-01-2018.
 */

public class SpinnerItems {
    private String mytitle;

    public SpinnerItems(String mytitle){
        this.mytitle=mytitle;
    }
    public String getTitle() {
        return mytitle;
    }

    public void setTitle(String mytitle) {
        this.mytitle = mytitle;
    }
}
